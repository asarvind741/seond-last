import 'babel-polyfill';

module.exports = {};
